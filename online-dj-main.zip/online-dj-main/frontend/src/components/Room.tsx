
const Room = () => {
    // Add your component's logic here

    return (
        <div>
        </div>
    );
};

export default Room;